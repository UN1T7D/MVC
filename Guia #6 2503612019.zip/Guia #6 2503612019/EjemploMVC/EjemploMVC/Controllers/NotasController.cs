﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EjemploMVC.Models;

namespace EjemploMVC.Controllers
{
    public class NotasController : Controller
    {
        // GET: Notas
        public ActionResult Notas()
        {
            return View();
        }

        // POST: Prueba/Index
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Notas(Notas obPromedio)
        {
            string msj = "";

            double prom = (obPromedio.Actividades + obPromedio.Laboratorio + obPromedio.Parcial) / 3;
            if (prom == 10)
            {
                msj = "FELICIDADES, ERES EL MEJOR :D";
            }
            else if (prom <10 && prom >=7)
            {
                msj = "Bueno... Al menos aprobaste XD";
            }
            else if (prom < 7 && prom > 4)
            {
                msj = "Te veo el otro ciclo bro :l";
            }
            else if (prom <= 4)
            {
                msj = "Oye... ¿Todo bien en casa? D: Deberias visitar a tu docente bro...";
            }

            ViewBag.Promedio = prom;
            ViewBag.Mensaje = msj;
            return View(obPromedio);
        }
    }
}