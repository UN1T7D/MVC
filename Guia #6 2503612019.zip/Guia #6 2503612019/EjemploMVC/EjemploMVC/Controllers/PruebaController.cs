﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EjemploMVC.Models;

namespace EjemploMVC.Controllers
{
    public class PruebaController : Controller
    {
        // GET: Prueba
        public ActionResult Index()
        {
            return View();
        }

        // POST: Prueba/Index
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(Calculo obCalculo)
        {
            int result = 0;
            if (obCalculo.operacion == "Suma")
            {
                result = obCalculo.numero1 + obCalculo.numero2;
            }
            else if (obCalculo.operacion == "Resta")
            {
                result = obCalculo.numero1 - obCalculo.numero2;
            }
            else if (obCalculo.operacion == "Multiplicacion")
            {
                result = obCalculo.numero1 * obCalculo.numero2;
            }
            else if (obCalculo.operacion == "Division")
            {
                result = obCalculo.numero1 / obCalculo.numero2;
            }
            ViewBag.resultado = result;
            return View(obCalculo);
        }
    }
}