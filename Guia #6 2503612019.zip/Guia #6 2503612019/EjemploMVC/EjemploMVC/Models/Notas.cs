﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EjemploMVC.Models
{
    public class Notas
    {
        public double Actividades { get; set; }
        public double Laboratorio { get; set; }
        public double Parcial { get; set; }
    }
}