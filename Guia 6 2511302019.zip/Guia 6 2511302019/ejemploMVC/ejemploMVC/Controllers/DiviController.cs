﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ejemploMVC.Models;

namespace ejemploMVC.Controllers
{
    public class DiviController : Controller
    {
        // GET: Divi
        public ActionResult Divi()
        {
            return View();
        }

        // POST: Divi/Divi
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Divi(Divi obDivi)
        {
            //Resta
            try
            {
                int resultado = obDivi.numero1 / obDivi.numero2;
                ViewBag.resultado = resultado;
            }
            catch
            {
                ViewBag.resultado = "La operación no existe";
            }
            
            return View(obDivi);
        }
    }
}