﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ejemploMVC.Models;

namespace ejemploMVC.Controllers
{
    public class LongitudController : Controller
    {
        // GET: Longitud
        public ActionResult Longitud()
        {
            return View();
        }

        // POST: Longitud/Longitud
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Longitud(Longitud obLongitud)
        {
            //Peso
            double m = obLongitud.valor / 39.370;
            double p = obLongitud.valor * 39.370;
            ViewBag.l = m;
            ViewBag.kg = p;
            return View(obLongitud);
        }
    }
}