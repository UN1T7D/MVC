﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ejemploMVC.Models;

namespace ejemploMVC.Controllers
{
    public class MultiController : Controller
    {
        // GET: Multi
        public ActionResult Multi()
        {
            return View();
        }

        // POST: Multi/Multi
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Multi(Multi obMulti)
        {
            //Resta
            int resultado = obMulti.numero1 * obMulti.numero2;
            ViewBag.resultado = resultado;
            return View(obMulti);
        }
    }
}