﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ejemploMVC.Models;

namespace ejemploMVC.Controllers
{
    public class NotasController : Controller
    {
        // GET: Notas
        public ActionResult Notas()
        {
            return View();
        }
        // POST: Notas/Notas
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Notas(Notas obNotas)
        {
            double promedio = (obNotas.nota1 + obNotas.nota2 + obNotas.nota3) / 3;
            if (promedio > 10)
            {
                ViewBag.promedio = " Ingrese Notas Validas";
            }
            else
            {
                if (promedio == 10)
                {
                    ViewBag.promedio = promedio + " Felicidades";
                }
                else
                {
                    if (promedio >= 7 && promedio < 10)
                    {
                        ViewBag.promedio = promedio + " Aprobado";
                    }
                    else
                    {
                        if (promedio > 4 && promedio < 7)
                        {
                            ViewBag.promedio = promedio + " Aplazado";
                        }
                        else
                        {
                            ViewBag.promedio = promedio + " Visite al Tutor";
                        }
                    }
                }
            }
            return View(obNotas);
        }
    }
}