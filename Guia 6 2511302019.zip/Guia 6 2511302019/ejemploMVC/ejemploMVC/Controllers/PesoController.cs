﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ejemploMVC.Models;

namespace ejemploMVC.Controllers
{
    public class PesoController : Controller
    {
        // GET: Peso
        public ActionResult Peso()
        {
            return View();
        }

        // POST: Peso/Peso
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Peso(Peso obPeso)
        {
            //Peso
            double l = obPeso.valor * 2.2046;
            double kg = obPeso.valor / 2.2046;
            ViewBag.l = l;
            ViewBag.kg = kg;
            return View(obPeso);
        }
    }
}