﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ejemploMVC.Models;

namespace ejemploMVC.Controllers
{
    public class RestaController : Controller
    {
        // GET: Resta
        public ActionResult Resta()
        {
            return View();
        }

        // POST: Resta/Resta
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Resta(Resta obResta)
        {
            //Resta
            int resultado = obResta.numero1 - obResta.numero2;
            ViewBag.resultado = resultado;
            return View(obResta);
        }
    }
}