﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ejemploMVC.Models;

namespace ejemploMVC.Controllers
{
    public class TempController : Controller
    {
        // GET: Temp
        public ActionResult Temp()
        {
            return View();
        }

        // POST: Temperatura/Temperatura
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Temp(Temp obTemp)
        {
            //Temperatura
            double celcius = obTemp.valor - 273.15;
            double kelvin = obTemp.valor + 273.15;
            ViewBag.celcius = celcius;
            ViewBag.kelvin = kelvin;
            return View(obTemp);
        }
    }
}