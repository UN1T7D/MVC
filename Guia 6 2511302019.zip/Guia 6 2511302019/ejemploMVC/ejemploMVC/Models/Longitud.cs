﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class Longitud
    {
        public double valor { get; set; }
    }
}