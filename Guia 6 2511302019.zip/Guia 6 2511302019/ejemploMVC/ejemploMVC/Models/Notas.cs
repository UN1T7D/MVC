﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class Notas
    {
        public double nota1 { get; set; }
        public double nota2 { get; set; }
        public double nota3 { get; set; }
    }
}