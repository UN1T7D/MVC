﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class Resta
    {
        public int numero1 { get; set; }
        public int numero2 { get; set; }
    }
}