﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ejemploMVC.Models;

namespace ejemploMVC.Controllers
{
    public class PruebaController : Controller
    {
        // GET: Prueba
        public ActionResult Index()
        {
            return View();
        }
        // POST: Prueba/Index
        [HttpPost]
        [ValidateAntiForgeryToken]

        // Ejercicio 1
        public ActionResult Index(Calculo obCalculo)
        {
            int division;
            //Suma
            int suma = obCalculo.num1 + obCalculo.num2;
            //Resta
            int resta = obCalculo.num1 - obCalculo.num2;
            //Multiplicacion
            int multi = obCalculo.num1 * obCalculo.num2;
            //Division
            if (obCalculo.num2 != 0)
            {
                division = obCalculo.num1 / obCalculo.num2;
            }
            else
            {
                division = 0;
            }


            ViewBag.suma = suma;
            ViewBag.resta = resta;
            ViewBag.multi = multi;
            ViewBag.division = division;
            return View(obCalculo);
        }

        //Ejercicio 2
        //Celcius a Kelvin y vicebersa
        public ActionResult ConvertT(ConvertTemperatura obCT)
        {
            double kelvin = 273.15, resultado = 0;
            if (obCT.convertir_a == 1)
            {
                resultado = obCT.valor_a_convertir + kelvin;
            }
            else
            {
                resultado = obCT.valor_a_convertir - kelvin;
            }

            ViewBag.opc = obCT.convertir_a;
            ViewBag.valor = obCT.valor_a_convertir;
            ViewBag.resultado = resultado;

            return View(obCT);
        }
        //Kilogramos a Libras y vicebersa
        public ActionResult ConvertP(ConvertPeso obCP)
        {
            double libras = 2.205, resultado = 0;
            if (obCP.convertir_a == 1)
            {
                resultado = obCP.valor_a_convertir * libras;
            }
            else
            {
                resultado = obCP.valor_a_convertir / libras;
            }

            ViewBag.opc = obCP.convertir_a;
            ViewBag.valor = obCP.valor_a_convertir;
            ViewBag.resultado = resultado;

            return View(obCP);
        }
        //Metros a pulgadas y vicebersa
        public ActionResult ConvertL(ConvertLongitud obCL)
        {
            double pulg = 39.3701, resultado = 0;
            if (obCL.convertir_a == 1)
            {
                resultado = obCL.valor_a_convertir * pulg;
            }
            else
            {
                resultado = obCL.valor_a_convertir / pulg;
            }

            ViewBag.opc = obCL.convertir_a;
            ViewBag.valor = obCL.valor_a_convertir;
            ViewBag.resultado = resultado;

            return View(obCL);
        }

        //Ejercicio 3
        public ActionResult Promedio (Promedio obPromedio)
        {
            decimal promedio = (obPromedio.nota1 + obPromedio.nota2 + obPromedio.nota3) / 3;
            ViewBag.promedio = promedio;
            return View(obPromedio);
        }
        

    }
}