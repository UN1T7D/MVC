﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class Calculo
    {
        public int num1 { get; set; }
        public int num2 { get; set; }
    }
}