﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class ConvertPeso
    {
        public double valor_a_convertir { get; set; }
        public int convertir_a { get; set; }
    }
}