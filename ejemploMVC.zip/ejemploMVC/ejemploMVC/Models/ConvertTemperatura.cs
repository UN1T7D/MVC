﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class ConvertTemperatura
    {
        public double valor_a_convertir { get; set; }
        public int convertir_a { get; set; }

    }
}