﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ejemploMVC.Models
{
    public class Promedio
    {
        public decimal nota1 { get; set; }
        public decimal nota2 { get; set; }
        public decimal nota3 { get; set; }
    }
}